import csv
import argparse
import sys

def deduplicate_csv(input_path, output_path, key_columns):
    seen = set()
    with open(input_path, newline='', encoding='utf-8') as infile, \
         open(output_path, 'w', newline='', encoding='utf-8') as outfile:
        reader = csv.DictReader(infile)
        writer = csv.DictWriter(outfile, fieldnames=reader.fieldnames)
        writer.writeheader()
        for row in reader:
            key = tuple(row[col] for col in key_columns)
            if key not in seen:
                seen.add(key)
                writer.writerow(row)
    print(f\"Deduplication done. Output saved to {output_path}\")

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Deduplicate CSV rows based on key columns')
    parser.add_argument('input_csv', help='Input CSV file path')
    parser.add_argument('output_csv', help='Output CSV file path')
    parser.add_argument('--keys', nargs='+', required=True, help='Key columns for duplicate detection')
    args = parser.parse_args()
    deduplicate_csv(args.input_csv, args.output_csv, args.keys)
