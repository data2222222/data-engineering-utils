import csv
import argparse
from collections import defaultdict

def profile_csv(csv_path):
    with open(csv_path, newline='', encoding='utf-8') as csvfile:
        reader = csv.DictReader(csvfile)
        stats = {}
        counts = defaultdict(int)
        sums = defaultdict(float)
        mins = {}
        maxs = {}
        total_rows = 0

        for row in reader:
            total_rows += 1
            for col, val in row.items():
                if val == '':
                    counts[col] += 1  # count missing
                    continue
                try:
                    num = float(val)
                    sums[col] = sums.get(col, 0) + num
                    mins[col] = min(mins.get(col, num), num)
                    maxs[col] = max(maxs.get(col, num), num)
                except ValueError:
                    pass

        print(f\"Total rows: {total_rows}\n")
        for col in reader.fieldnames:
            missing = counts.get(col, 0)
            avg = sums.get(col, 0) / (total_rows - missing) if total_rows - missing > 0 else 'N/A'
            min_val = mins.get(col, 'N/A')
            max_val = maxs.get(col, 'N/A')
            print(f\"Column: {col}\\n  Missing: {missing}\\n  Average: {avg}\\n  Min: {min_val}\\n  Max: {max_val}\\n\")

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Profile a CSV file')
    parser.add_argument('csv_path', help='Path to CSV file')
    args = parser.parse_args()
    profile_csv(args.csv_path)
