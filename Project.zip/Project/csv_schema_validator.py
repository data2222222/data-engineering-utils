import json
import csv
import argparse
import sys

def validate_csv(csv_path, schema_path):
    with open(schema_path, 'r') as f:
        schema = json.load(f)
    required_columns = schema.get('required', [])
    column_types = schema.get('properties', {})

    with open(csv_path, newline='', encoding='utf-8') as csvfile:
        reader = csv.DictReader(csvfile)
        errors = []
        row_num = 1
        for row in reader:
            for col in required_columns:
                if col not in row or row[col] == '':
                    errors.append(f"Row {row_num}: Missing required column '{col}'")
            for col, col_info in column_types.items():
                if col in row and row[col] != '':
                    val = row[col]
                    expected_type = col_info.get('type')
                    if expected_type == 'integer':
                        if not val.isdigit():
                            errors.append(f\"Row {row_num}: Column '{col}' expected integer but got '{val}'\")
                    elif expected_type == 'number':
                        try:
                            float(val)
                        except ValueError:
                            errors.append(f\"Row {row_num}: Column '{col}' expected number but got '{val}'\")
            row_num += 1

    if errors:
        print(\"Validation errors:\")
        for err in errors:
            print(\" - \" + err)
        sys.exit(1)
    else:
        print(\"CSV validation passed successfully.\")

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Validate CSV against JSON schema')
    parser.add_argument('csv_path', help='Path to CSV file')
    parser.add_argument('schema_path', help='Path to JSON schema file')
    args = parser.parse_args()
    validate_csv(args.csv_path, args.schema_path)
