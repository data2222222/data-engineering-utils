# Data Engineering Utilities

Collection of simple, useful data engineering tools in Python.

## Tools

### 1. CSV Schema Validator  
Validate CSV files against a JSON schema.  
Usage:
```bash
python csv_schema_validator.py data.csv schema.json
