import json
import argparse

def schema_to_sql(schema_path, table_name, dialect='postgresql'):
    with open(schema_path, 'r') as f:
        schema = json.load(f)
    fields = schema.get('fields', [])

    type_map = {
        'string': 'VARCHAR',
        'integer': 'INTEGER',
        'number': 'FLOAT',
        'boolean': 'BOOLEAN'
    }
    if dialect == 'mysql':
        type_map['string'] = 'VARCHAR(255)'

    columns = []
    for field in fields:
        name = field['name']
        dtype = field.get('type', 'string')
        sql_type = type_map.get(dtype, 'TEXT')
        columns.append(f\"`{name}` {sql_type}\")

    sql = f\"CREATE TABLE {table_name} (\\n  \" + \",\\n  \".join(columns) + \"\\n);\"
    print(sql)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Generate SQL CREATE TABLE from JSON schema')
    parser.add_argument('schema_path', help='Path to JSON schema')
    parser.add_argument('table_name', help='Name of SQL table to create')
    parser.add_argument('--dialect', default='postgresql', choices=['postgresql', 'mysql'], help='SQL dialect')
    args = parser.parse_args()
    schema_to_sql(args.schema_path, args.table_name, args.dialect)
