import csv
import argparse
import psycopg2

def load_incremental_csv(db_config, csv_path, table_name, unique_key):
    conn = psycopg2.connect(**db_config)
    cur = conn.cursor()

    # Load unique keys already in table
    cur.execute(f\"SELECT {unique_key} FROM {table_name};\")
    existing_keys = set(row[0] for row in cur.fetchall())

    with open(csv_path, newline='', encoding='utf-8') as csvfile:
        reader = csv.DictReader(csvfile)
        rows_to_insert = [row for row in reader if row[unique_key] not in existing_keys]

    if not rows_to_insert:
        print(\"No new rows to insert.\")
        return

    columns = rows_to_insert[0].keys()
    values_str = ','.join([f\"%({col})s\" for col in columns])
    insert_query = f\"INSERT INTO {table_name} ({', '.join(columns)}) VALUES ({values_str})\"

    for row in rows_to_insert:
        cur.execute(insert_query, row)
    conn.commit()
    cur.close()
    conn.close()

    print(f\"Inserted {len(rows_to_insert)} new rows into {table_name}.\")

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Incrementally load CSV into PostgreSQL')
    parser.add_argument('--host', required=True)
    parser.add_argument('--port', type=int, default=5432)
    parser.add_argument('--user', required=True)
    parser.add_argument('--password', required=True)
    parser.add_argument('--dbname', required=True)
    parser.add_argument('csv_path', help='CSV file path')
    parser.add_argument('table_name', help='Target table name')
    parser.add_argument('unique_key', help='Unique key column name')
    args = parser.parse_args()

    db_config = {
        'host': args.host,
        'port': args.port,
        'user': args.user,
        'password': args.password,
        'dbname': args.dbname
    }
    load_incremental_csv(db_config, args.csv_path, args.table_name, args.unique_key)
